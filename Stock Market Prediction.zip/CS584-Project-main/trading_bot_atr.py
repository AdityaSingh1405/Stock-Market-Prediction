#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Alpaca Trading Bot with ATR Integration
---------------------------------------
- Uses `ta` library's Average True Range for:
  * Risk-based position sizing
  * ATR-scaled limit entries
  * Volatility filters
  * Optional ATR-based bracket orders / trailing exits
- Keeps your original flow (signals from CSV, reversals, duplicate-order checks, etc.)

Requirements:
    pip install alpaca-trade-api ta pandas pytz holidays numpy
"""

from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import pytz
import time
import os
from warnings import filterwarnings
import configparser
import holidays
from alpaca_trade_api.rest import REST, APIError, TimeFrame
from ta.volatility import AverageTrueRange

# ------------------------------
# Global config / warnings
# ------------------------------

filterwarnings("ignore")

# Track original limit prices (symbol -> original limit price) if you want to
# keep the pre-close adjustment behavior.
original_limit_prices = {}

# ------------------------------
# Config & API
# ------------------------------

def load_config(config_path='../../Keys/config.ini'):
    """Load API configuration settings."""
    conf = configparser.ConfigParser()
    conf.read(config_path)
    return {
        'api_key': conf['alpaca']['api_key'],
        'api_secret': conf['alpaca']['api_secret'],
        'base_url': 'https://paper-api.alpaca.markets'
    }

def init_api(conf):
    """Initialize and return the Alpaca API client."""
    return REST(conf['api_key'], conf['api_secret'], conf['base_url'])

# ------------------------------
# Data I/O
# ------------------------------

def fetch_historical_data(file_path="optimized_results.csv"):
    """Load historical signals from a CSV (expects columns: Symbol, Last_Signal)."""
    try:
        data = pd.read_csv(file_path)
        if not {'Symbol', 'Last_Signal'}.issubset(set(data.columns)):
            raise ValueError("CSV must include at least ['Symbol', 'Last_Signal'] columns.")
        return data
    except FileNotFoundError:
        print("No data file found")
        return pd.DataFrame()
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return pd.DataFrame()

def fetch_bars_df(api, symbol, days=60, timeframe=TimeFrame.Day):
    """
    Pull recent OHLCV bars for a symbol and return DataFrame with index=timestamp
    columns: ['open','high','low','close','volume']
    """
    try:
        end = pd.Timestamp.utcnow().tz_localize('UTC')
    except TypeError:
        # if end is already tz-aware
        end = pd.Timestamp.utcnow()
        if end.tzinfo is None:
            end = end.tz_localize('UTC')
    start = end - pd.Timedelta(days=days*2)  # buffer for holidays

    try:
        bars = api.get_bars(symbol, timeframe, start.isoformat(), end.isoformat()).df
    except Exception as e:
        print(f"[get_bars] {symbol} failed: {e}")
        return pd.DataFrame()

    if bars is None or len(bars) == 0:
        return pd.DataFrame()

    # If multiindex (from multi-symbol pulls), select this symbol
    if isinstance(bars.index, pd.MultiIndex):
        if symbol in bars.index.get_level_values(0):
            bars = bars.xs(symbol, level=0)
        else:
            return pd.DataFrame()

    rename_map = {'t':'timestamp','o':'open','h':'high','l':'low','c':'close','v':'volume'}
    cols = {k: v for k, v in rename_map.items() if k in bars.columns}
    bars = bars.rename(columns=cols)

    # Keep only expected columns if present
    keep = [c for c in ['open','high','low','close','volume'] if c in bars.columns]
    bars = bars[keep].copy()

    # Ensure datetime index
    try:
        bars.index = pd.to_datetime(bars.index)
    except Exception:
        pass

    return bars

# ------------------------------
# ATR utilities
# ------------------------------

def compute_atr(df, period=14):
    """
    Compute ATR and ATR% (ATR/close). Returns last ATR values (float, float).
    """
    if df is None or df.empty or len(df) < period + 2:
        return None, None, None

    if not set(['high','low','close']).issubset(set(df.columns)):
        return None, None, None

    atr_ind = AverageTrueRange(
        high=df['high'], low=df['low'], close=df['close'], window=period
    )
    atr_series = atr_ind.average_true_range()
    atr = atr_series.iloc[-1]
    last_close = df['close'].iloc[-1]
    atr_pct = atr / last_close if last_close and last_close > 0 else None
    return float(atr), (float(atr_pct) if atr_pct is not None else None), float(last_close)

def batch_atr_map(api, symbols, period=14, days=60):
    """
    Compute ATR for many symbols. Returns dict:
        {symbol: {'atr':x, 'atr_pct':y, 'last_close':z}}
    """
    out = {}
    for s in symbols:
        try:
            df = fetch_bars_df(api, s, days=days, timeframe=TimeFrame.Day)
            atr, atr_pct, last_close = compute_atr(df, period=period)
            if atr is not None:
                out[s] = {'atr': atr, 'atr_pct': atr_pct, 'last_close': last_close}
        except Exception as e:
            print(f"[ATR] failed {s}: {e}")
    return out

def atr_position_size(equity, risk_per_trade=0.005, atr=None, stop_mult=2.0):
    """
    Risk-based sizing: qty = risk_amount / stop_distance (ATR * stop_mult).
    risk_per_trade: fraction of equity you risk per trade (e.g., 0.5%).
    """
    if atr is None or atr <= 0:
        return 0
    risk_amount = equity * risk_per_trade
    stop_dist = atr * stop_mult
    if stop_dist <= 0:
        return 0
    qty = int(np.floor(risk_amount / stop_dist))
    return max(qty, 0)

def atr_limit_price(side, ref_price, atr=None, k=0.5, hard_cap_pct=0.02):
    """
    Use ATR to set limit slippage. Move price by k*ATR but cap it by hard_cap_pct of price.
    For buys: below ref_price; for sells/shorts: above ref_price.
    """
    if ref_price is None or ref_price <= 0:
        return None
    adj = (atr if (atr is not None and atr > 0) else ref_price * hard_cap_pct) * k
    cap = ref_price * hard_cap_pct
    off = min(adj, cap)
    return round(ref_price - off, 2) if side == 'buy' else round(ref_price + off, 2)

def passes_vol_filter(atr_pct, min_atr_pct=0.008, max_atr_pct=0.08):
    """
    Skip names too quiet (<0.8% ATR) or too wild (>8% ATR).
    """
    if atr_pct is None:
        return True
    return (atr_pct >= min_atr_pct) and (atr_pct <= max_atr_pct)

def submit_bracket_with_atr(api, symbol, side, qty, entry_price, atr, stop_mult=2.0, tp_mult=3.0):
    """
    Bracket orders using ATR-sized stop and take profit.
    """
    if qty < 1 or atr is None or atr <= 0 or entry_price is None or entry_price <= 0:
        return

    if side == 'buy':
        stop_price = round(entry_price - atr * stop_mult, 2)
        take_limit = round(entry_price + atr * tp_mult, 2)
    else:  # sell/short
        stop_price = round(entry_price + atr * stop_mult, 2)
        take_limit = round(entry_price - atr * tp_mult, 2)

    print(f"[BRACKET] {symbol} qty={qty} entry≈{entry_price:.2f} SL={stop_price:.2f} TP={take_limit:.2f}")
    api.submit_order(
        symbol=symbol,
        qty=qty,
        side=side,
        type='limit',
        limit_price=round(entry_price, 2),
        time_in_force='gtc',
        order_class='bracket',
        take_profit={'limit_price': take_limit},
        stop_loss={'stop_price': stop_price}
    )

def convert_to_trailing_by_atr(api, symbol, current_side, atr, trail_mult=2.0):
    """
    Replace open orders with a trailing stop sized by ATR in dollars.
    Alpaca trailing orders accept trail_price (absolute $ trail).
    """
    if atr is None or atr <= 0:
        return
    # Determine current position qty
    try:
        pos = api.get_position(symbol)
        qty = abs(int(pos.qty))
        if qty < 1:
            return
        # Close existing open orders first
        for o in api.list_orders(status='open', symbols=[symbol]):
            try:
                api.cancel_order(o.id)
            except Exception:
                pass
        trail_price = round(atr * trail_mult, 2)
        exit_side = 'sell' if current_side == 'buy' else 'buy'
        print(f"[TRAIL] {symbol} {exit_side} qty={qty} trail=${trail_price:.2f}")
        api.submit_order(
            symbol=symbol,
            qty=qty,
            side=exit_side,
            type='trail',
            time_in_force='gtc',
            trail_price=trail_price
        )
    except Exception as e:
        print(f"[TRAIL] {symbol} failed: {e}")

# ------------------------------
# Utility & logging
# ------------------------------

def log_limit_adjustment(symbol, old_signal, new_signal, reason):
    """
    Log changes in trading signals to a file.
    """
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, "limit_adjustment_log.txt")
    with open(log_file, "a") as f:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        f.write(f"{timestamp} - {symbol} - Signal changed: {old_signal} \u2192 {new_signal} - {reason}\n")

def is_weekday(date):
    """Check if the date is a weekday."""
    return date.weekday() < 5

def is_holiday(date):
    """Check if the date is a US market holiday."""
    us_holidays = holidays.US(years=date.year)
    return date.date() in us_holidays

def get_next_market_open(current):
    """Calculate the next market open time considering weekends and holidays."""
    open_time = current.replace(hour=9, minute=30, second=0, microsecond=0)
    if current >= open_time or not is_weekday(current) or is_holiday(current):
        current += timedelta(days=1)
        current = current.replace(hour=9, minute=30, second=0, microsecond=0)
    else:
        return open_time
    while not is_weekday(current) or is_holiday(current):
        current += timedelta(days=1)
    return current

def print_progress_bar(total_seconds):
    """Print a progress bar showing remaining time with a rotating marker."""
    marker_positions = '|/-\\'
    start_time = datetime.now()
    end_time = start_time + timedelta(seconds=total_seconds)
    while datetime.now() < end_time:
        elapsed_time = (datetime.now() - start_time).total_seconds()
        remaining_seconds = max(0, total_seconds - elapsed_time)
        hours, remainder = divmod(remaining_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        progress_marker = marker_positions[int(elapsed_time) % len(marker_positions)]
        print(f"\r[{progress_marker}] Time remaining: {int(hours):02}:{int(minutes):02}h", end='')
        time.sleep(1)
    print()

# ------------------------------
# Order maintenance / end-of-day routines
# ------------------------------

def adjust_limit_orders(app_intf):
    """
    Adjust open limit orders once, 5 minutes before market close if the market price
    has deviated more than 5% from the original limit price.
    """
    log_entries = []
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    open_orders = app_intf.list_orders(status='open')
    for order in open_orders:
        symbol = order.symbol
        side = order.side
        try:
            qty = int(order.qty)
        except Exception:
            qty = int(float(order.qty))

        if symbol not in original_limit_prices:
            continue

        original_price = float(original_limit_prices[symbol])

        try:
            quote = app_intf.get_latest_quote(symbol)
            market_price = float(quote.bp or quote.ap or 0)
            if market_price == 0:
                continue

            deviation = abs(original_price - market_price) / market_price
            if deviation >= 0.05:
                # Cancel and replace
                app_intf.cancel_order(order.id)
                time.sleep(1)

                new_limit = round(
                    market_price * (1 - 0.02) if side == 'buy' else market_price * (1 + 0.02), 2
                )

                app_intf.submit_order(
                    symbol=symbol,
                    qty=qty,
                    side=side,
                    type='limit',
                    time_in_force='gtc',
                    limit_price=new_limit
                )

                original_limit_prices[symbol] = new_limit

                log_line = (
                    f"[{now_str}] Adjusted {side.upper()} LIMIT for {symbol} from ${original_price:.2f} "
                    f"to ${new_limit:.2f} (Market: ${market_price:.2f})"
                )
                print(log_line)
                log_entries.append(log_line)

        except Exception as err:
            print(f"Error adjusting order for {symbol}: {err}")

    if log_entries:
        log_file = "limit_adjustment_log.txt"
        with open(log_file, "a") as f:
            for line in log_entries:
                f.write(line + "\n")

def close_profitable_positions(app_intf):
    """
    Closes all long or short positions with at least 5% unrealized profit.
    """
    try:
        positions = app_intf.list_positions()
        profitable_positions = []
        for pos in positions:
            try:
                qty = int(pos.qty)
            except Exception:
                qty = int(float(pos.qty))
            if qty == 0:
                continue

            unrealized_pl = float(pos.unrealized_pl)
            market_value = float(pos.market_value)
            if market_value == 0:
                continue
            profit_pct = (unrealized_pl / market_value) * 100
            if profit_pct >= 5:
                profitable_positions.append((pos.symbol, qty, pos.side, profit_pct))

        if not profitable_positions:
            print("No positions with at least 5% profit to close.")
            return

        print(f"Found {len(profitable_positions)} profitable positions (\u22655%). Closing them now...")
        for symbol, qty, side, pct in profitable_positions:
            print(f"Closing {symbol}: {qty} shares ({side}) with {pct:.2f}% unrealized profit")
            try:
                app_intf.close_position(symbol)
                print(f"Closed {symbol}")
            except APIError as err:
                print(f"Failed to close {symbol}: {err}")

    except Exception as err:
        print(f"Error while closing profitable positions: {err}")

# ------------------------------
# Core execution (strategy)
# ------------------------------

def run_strategy(app_intf, symbol, last_signal, funds_per_stock, quote=None, existing_order=None,
                 atr_row=None, equity=None, use_brackets=True):
    """
    Executes per-symbol trading decision using ATR for sizing/limits/filters.
    - last_signal: 'Buy' or 'Sell'
    - atr_row: dict {'atr','atr_pct','last_close'}
    - equity: account equity for risk-based sizing
    - use_brackets: if True, place ATR-based bracket orders when possible
    """
    try:
        side = 'buy' if last_signal.lower() == 'buy' else 'sell'

        # Cancel conflicting short if trying to buy
        if side == 'buy':
            open_orders = app_intf.list_orders(status='open')
            for order in open_orders:
                if order.symbol == symbol and order.side == 'sell':
                    try:
                        print(f"[CANCEL] Conflicting short order found. Canceling before BUY: {symbol}")
                        app_intf.cancel_order(order.id)
                        time.sleep(1)
                    except Exception as cancel_err:
                        print(f"[ERROR] Failed to cancel short order for {symbol}: {cancel_err}")
                        return

        # Current position qty
        try:
            position = app_intf.get_position(symbol)
            try:
                position_qty = int(position.qty)
            except Exception:
                position_qty = int(float(position.qty))
        except APIError as error:
            position_qty = 0 if 'position does not exist' in str(error) else 0

        # Price
        if quote is None:
            quote = app_intf.get_latest_quote(symbol)
        current_price = quote.bp or quote.ap or 0
        if current_price == 0:
            print(f"Skipping {symbol}: No valid price.")
            return

        # Account info
        account = app_intf.get_account()
        available_cash = float(account.cash)
        buying_power = float(account.buying_power)
        if equity is None:
            equity = float(account.equity)

        # ATR info
        sym_atr = atr_row.get('atr') if atr_row else None
        sym_atr_pct = atr_row.get('atr_pct') if atr_row else None

        # Volatility filter
        if not passes_vol_filter(sym_atr_pct):
            print(f"[ATR-FILTER] Skip {symbol}: ATR% {sym_atr_pct:.4f} outside thresholds.")
            return

        qty = 0
        order_type = 'market'
        limit_price = None

        if last_signal == 'Buy':
            if position_qty < 0:
                # Cover short
                qty = abs(position_qty)
                order_type = 'market'
            else:
                # ATR sizing preferred, fallback to cash bucket
                atr_qty = atr_position_size(equity, risk_per_trade=0.005, atr=sym_atr, stop_mult=2.0) if sym_atr else 0
                cash_qty = int((min(funds_per_stock, available_cash)) / current_price)
                qty = max(atr_qty, cash_qty)
                # ATR-based entry limit a touch below market
                limit_price = atr_limit_price('buy', current_price, atr=sym_atr, k=0.5, hard_cap_pct=0.02)
                order_type = 'limit' if limit_price else 'market'

        elif last_signal == 'Sell':
            if position_qty > 0:
                # Liquidate long
                qty = position_qty
                order_type = 'market'
            elif position_qty == 0:
                # Initiate short with ATR sizing constrained by margin
                atr_qty = atr_position_size(equity, risk_per_trade=0.005, atr=sym_atr, stop_mult=2.0) if sym_atr else 0
                limit_price = atr_limit_price('sell', current_price, atr=sym_atr, k=0.5, hard_cap_pct=0.02)
                est_entry = limit_price or (current_price * 1.01)
                margin_buffer = 1.5
                max_qty = int(buying_power / (est_entry * margin_buffer))
                fallback_qty = int(funds_per_stock / est_entry) if funds_per_stock else 0
                qty = min(atr_qty if atr_qty > 0 else fallback_qty, max_qty)
                order_type = 'limit' if limit_price else 'limit'
            else:
                print(f"{symbol}: Already shorted. Holding.")
                return
        else:
            print(f"Unknown signal type '{last_signal}' for {symbol}.")
            return

        if qty < 1:
            print(f"Skipping {symbol}: Quantity too small.")
            return

        # Check for existing matching pending order
        if existing_order is not None and existing_order.side.lower() == side.lower():
            matching_orders = [existing_order]
        else:
            open_orders = app_intf.list_orders(status='open')
            matching_orders = [o for o in open_orders if o.symbol == symbol and o.side == side]

        if matching_orders:
            existing_order = matching_orders[0]
            try:
                existing_qty = int(existing_order.qty)
            except Exception:
                existing_qty = int(float(existing_order.qty))

            if qty > existing_qty:
                try:
                    app_intf.cancel_order(existing_order.id)
                    print(f"Cancelled existing order for {symbol}: {existing_qty} < {qty}")
                    time.sleep(1)
                except Exception as err:
                    print(f"Failed to cancel existing order for {symbol}: {err}")
                    return
            else:
                print(f"Skipping {symbol}: Existing order has equal or better quantity ({existing_qty} \u2265 {qty})")
                return

        # Place order
        if use_brackets and sym_atr and order_type == 'limit' and limit_price:
            submit_bracket_with_atr(
                app_intf, symbol, side, qty, entry_price=limit_price, atr=sym_atr,
                stop_mult=2.0, tp_mult=3.0
            )
            original_limit_prices[symbol] = float(limit_price)
        elif order_type == 'market':
            print(f"Placing MARKET {side.upper()} order for {symbol}: {qty} shares")
            app_intf.submit_order(
                symbol=symbol,
                qty=qty,
                side=side,
                type='market',
                time_in_force='gtc'
            )
        else:
            print(f"Placing {side.upper()} LIMIT order for {symbol}: {qty} @ ${limit_price:.2f}")
            app_intf.submit_order(
                symbol=symbol,
                qty=qty,
                side=side,
                type='limit',
                limit_price=limit_price,
                time_in_force='gtc'
            )
            original_limit_prices[symbol] = float(limit_price)

    except Exception as err:
        print(f"Error running strategy for {symbol}: {err}")

# ------------------------------
# Main loop
# ------------------------------

def main_loop():
    config = load_config()
    api = init_api(config)
    ny_tz = pytz.timezone('America/New_York')

    while True:
        try:
            now = datetime.now(ny_tz)
            market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
            market_close = now.replace(hour=16, minute=0, second=0, microsecond=0)

            formatted_time = now.strftime("%H:%M")
            print("\nCurrent Time (HH:MM): ", formatted_time, "\n")

            if (market_open <= now < market_close) and is_weekday(now) and not is_holiday(now):
                print("Market is open. Running the trading bot...")

                # ------- Load signals -------
                data = fetch_historical_data()
                if data.empty:
                    print("No trading data available.")
                    time.sleep(60)
                    continue

                # Account snapshot
                account = api.get_account()
                cash_available = float(account.cash)
                buying_power = float(account.buying_power)
                equity = float(account.equity)
                print(f"Total Cash Available: ${cash_available:.2f} | Buying Power: ${buying_power:.2f} | Equity: ${equity:.2f}")

                # Positions & open orders
                positions = api.list_positions()
                open_orders = api.list_orders(status='open')
                tickers_in_portfolio = {}
                for p in positions:
                    try:
                        tickers_in_portfolio[p.symbol] = int(p.qty)
                    except Exception:
                        tickers_in_portfolio[p.symbol] = int(float(p.qty))
                pending_orders = {o.symbol: o for o in open_orders}

                # Signals
                buy_tickers = set(data[data['Last_Signal'] == 'Buy']['Symbol'])
                sell_tickers = set(data[data['Last_Signal'] == 'Sell']['Symbol'])
                print(f"Buy Signals: {len(buy_tickers)} | Sell Signals: {len(sell_tickers)}")

                # Quotes & ATR prefetch for all symbols we may touch
                all_symbols_to_process = list(buy_tickers.union(sell_tickers))
                quotes = {}
                for s in all_symbols_to_process:
                    try:
                        quotes[s] = api.get_latest_quote(s)
                    except Exception as e:
                        print(f"[Quote] {s} failed: {e}")

                atr_map = batch_atr_map(api, all_symbols_to_process, period=14, days=60)

                # ---------------- BUY PATH ----------------
                if buying_power > 0 and buy_tickers:
                    new_buys = buy_tickers  # allow buys even if already long? you can filter here
                    if new_buys:
                        # funds per new buy (cash bucket if ATR sizing fails)
                        per_buy_funds = max(0.0, (buying_power * 0.9) / max(1, len(new_buys)))
                        print(f"Allocated Funds Per BUY Stock: ${per_buy_funds:.2f}")

                        for symbol in new_buys:
                            # If short, auto-cover
                            if symbol in tickers_in_portfolio and tickers_in_portfolio[symbol] < 0:
                                qty_to_cover = abs(int(tickers_in_portfolio[symbol]))
                                existing_order = pending_orders.get(symbol)
                                if existing_order and existing_order.side == "sell":
                                    try:
                                        print(f"[CANCEL] Cancel pending short limit order for {symbol}")
                                        api.cancel_order(existing_order.id)
                                        time.sleep(1)
                                    except Exception as e:
                                        print(f"[ERROR] Could not cancel short order for {symbol}: {e}")
                                try:
                                    print(f"[REVERSE] Cover short for {symbol}: {qty_to_cover} shares")
                                    api.submit_order(
                                        symbol=symbol,
                                        qty=qty_to_cover,
                                        side="buy",
                                        type="market",
                                        time_in_force="day"
                                    )
                                    time.sleep(1)
                                except Exception as e:
                                    print(f"[ERROR] Failed to cover short for {symbol}: {e}")
                                    continue

                            run_strategy(
                                api, symbol, "Buy", per_buy_funds,
                                quote=quotes.get(symbol),
                                existing_order=pending_orders.get(symbol),
                                atr_row=atr_map.get(symbol),
                                equity=equity,
                                use_brackets=True
                            )
                    else:
                        print("No new tickers to buy.")
                else:
                    print("Insufficient buying power for buys.")

                # ---------------- SELL / SHORT PATH ----------------
                if sell_tickers:
                    new_shorts = {
                        symbol for symbol in sell_tickers
                        if (symbol not in tickers_in_portfolio or tickers_in_portfolio[symbol] >= 0)
                    }
                    print(f"Processing {len(new_shorts)} SELL/SHORT signals...")
                    num_new_shorts = len(new_shorts)
                    per_short_funds = (buying_power * 0.9 / num_new_shorts) if num_new_shorts > 0 else 0.0

                    for symbol in new_shorts:
                        if symbol in tickers_in_portfolio and tickers_in_portfolio[symbol] > 0:
                            # Liquidate existing long
                            run_strategy(
                                api, symbol, "Sell", 0,
                                quote=quotes.get(symbol),
                                existing_order=pending_orders.get(symbol),
                                atr_row=atr_map.get(symbol),
                                equity=equity,
                                use_brackets=False  # liquidation as market is fine
                            )
                        else:
                            try:
                                run_strategy(
                                    api, symbol, "Sell", per_short_funds,
                                    quote=quotes.get(symbol),
                                    existing_order=pending_orders.get(symbol),
                                    atr_row=atr_map.get(symbol),
                                    equity=equity,
                                    use_brackets=True
                                )
                            except Exception as err:
                                print(f"Error preparing short for {symbol}: {err}")

                # ---- Daily summary ----
                account = api.get_account()
                equity = float(account.equity)
                last_equity = float(account.last_equity)
                delta = round(equity - last_equity, 2)

                print(f"\nCurrent Time: {datetime.now().strftime('%H:%M')}")
                print(f"Daily P/L Change: ${delta:.2f}")

                # Pre-close maintenance (3:55 PM)
                if now >= market_close - timedelta(minutes=5):
                    print("\nChecking for limit order adjustments (5 mins before close)...")
                    adjust_limit_orders(api)
                    print("\n\u23F1\uFE0F 3:55 PM ET: Closing profitable positions...")
                    close_profitable_positions(api)
                    # Example: convert open positions to trailing stops by ATR if desired:
                    # for sym in tickers_in_portfolio.keys():
                    #     a = atr_map.get(sym, {}).get('atr')
                    #     if a:
                    #         convert_to_trailing_by_atr(api, sym, current_side='buy', atr=a, trail_mult=2.0)

                # Sleep for 5 minutes
                time.sleep(300)

            else:
                next_open = get_next_market_open(now)
                sleep_seconds = int((next_open - now).total_seconds())
                print(f"Market is closed. Next opening at {next_open.strftime('%Y-%m-%d %H:%M:%S %Z')}.")
                print_progress_bar(sleep_seconds)

        except KeyboardInterrupt:
            print("Script terminated by user.")
            break
        except Exception as e:
            print(f"An error occurred: {e}")
            # Re-raise if you want a hard crash:
            # raise

# ------------------------------
# Entrypoint
# ------------------------------

if __name__ == "__main__":
    main_loop()
